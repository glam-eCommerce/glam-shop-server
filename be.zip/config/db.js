// const mongoose = require("mongoose");
const mongoose = require("mongoose");

require('dotenv').config();
const uri = 'mongodb://root:Glamecommerce!123@glam-mongodb.cluster-cf6vaav49w2p.ap-southeast-1.docdb.amazonaws.com:27017/ecommerce?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false'

try {
//   const client = new MongoClient(uri, {tlsCAFile: `../rds-combined-ca-bundle.pem`})
//   client.connect()
//   console.log("==============Mongodb Database Connected Successfully==============")
// } catch(err) {
//   console.log("Database Not Connected !!!")
// }

  console.log(uri)
  mongoose.connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
    tls:true,
    tlsCAFile: `global-bundle.pem`,
    tlsAllowInvalidHostnames:true,
    tlsAllowInvalidCertificates:true
  });
  console.log("Database Connected Successfully");
} catch (err) {
  console.log("Database Not Connected");
}
